import java.util.*;

public class Core{
  
  public static void main(String[]args){

    
    Tabuleiroo numbers = new Tabuleiroo();
    numbers.blockGenerator();
    numbers.printer();
    numbers.gravityTetramino();
    System.out.println();
    numbers.printer();
    numbers.tester();
    numbers.crusher();
    System.out.println();
    numbers.printer();
    
  }
}